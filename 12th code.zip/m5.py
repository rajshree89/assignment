from my_package import list1, set2, dict3

list1.append1("hello")
set2.adds2(10)
dict3.add3("a", 1)