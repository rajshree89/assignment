from my_package import append1, adds2, add3

append1("Hi")
adds2(5)
add3("name", "Alice")